"""
VDC - Versatile Data Cleanser Based on Semantic Inconsistency
"""

__version__ = "2.0.0"
